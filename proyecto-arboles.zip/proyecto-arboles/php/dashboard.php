<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

include 'db_config.php';

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT latitude, longitude FROM arboles WHERE estudiante_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($latitude, $longitude);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .content {
            flex: 1;
        }

        .jumbotron {
            background-color: rgba(233, 236, 239, 0.9);
            padding: 2rem 1rem;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
        }

        .footer {
            padding: 20px 0;
            background-color: #343a40;
            color: white;
        }

        .navbar-brand img {
            max-height: 50px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="../img/logo_Ceutec.png" alt="Logo">
                Siembra de Árboles
            </a>
        </div>
    </nav>

    <div class="jumbotron text-center">
        <div class="container">
            <h1 class="display-4">Bienvenido</h1>
        </div>
    </div>

    <div class="container mt-5 content">
        <h2 class="text-center">Bienvenido, Estudiante!</h2>

        <?php if ($latitude && $longitude): ?>
            <div class="text-center mt-3">
                <p>Ya has registrado tu árbol. Haz clic abajo para ver tu árbol en el mapa.</p>
                <a href="mapa.php" class="btn btn-primary">Ver mi árbol en el mapa</a>
            </div>
        <?php else: ?>
            <div class="text-center mt-3">
                <p>No has registrado tu árbol todavía. Haz clic abajo para registrar tu árbol.</p>
                <a href="../register_tree.html" class="btn btn-primary">Registrar mi árbol</a>
            </div>
        <?php endif; ?>
    </div>

    <footer class="footer text-center mt-auto">
        <div class="container">
            <img src="../img/logo_Ceutec.png" alt="Logo" style="max-width: 100px;">
            <p>© 2024 Proyecto de Siembra de Árboles</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
