<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

include 'db_config.php';

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT arboles.latitude, arboles.longitude, arboles.altura, arboles.circunferencia, arboles.foto, usuarios.nombre, arboles.fecha_siembra 
                        FROM arboles 
                        JOIN usuarios ON arboles.estudiante_id = usuarios.id 
                        WHERE estudiante_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($latitude, $longitude, $altura, $circunferencia, $foto_url, $nombre_estudiante, $fecha_registro);
$stmt->fetch();
$stmt->close();
$conn->close();

if (empty($latitude) || empty($longitude)) {
    header("Location: register_tree.html");
    exit;
}

$lat = $latitude;
$lng = $longitude;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubicación de tu Árbol</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #map { height: 400px; width: 100%; margin-bottom: 30px; }
        .tree-details { margin-top: 20px; }
        .tree-image { margin-top: 20px; max-width: 300px; max-height: 300px; border: 1px solid #ddd; padding: 10px; }
        .tree-info-table th { background-color: #f8f9fa; }
        .jumbotron {
            background-color: rgba(233, 236, 239, 0.9);
            padding: 1.5rem 1rem;
            margin-bottom: 1.5rem;
        }
        .footer {
            padding: 20px 0;
            background-color: #343a40;
            color: white;
        }
        .navbar-brand img {
            max-height: 50px;
            margin-right: 10px;
        }
        .directions-btn {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }
        .directions-btn:hover {
            background-color: #218838;
        }
        .directions-btn:focus {
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
        }
        .btn-all-trees {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }
        .btn-all-trees:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Navbar with Logo -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="../img/logo_Ceutec.png" alt="Logo">
                Siembra de Árboles
            </a>
        </div>
    </nav>

    <!-- Jumbotron -->
    <div class="jumbotron text-center">
        <div class="container">
            <h1 class="display-5">Ubicación y Detalles de tu Árbol</h1>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container mt-3">

        <div id="map"></div>

        <div class="text-center mb-4">
            <a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo $lat; ?>,<?php echo $lng; ?>" target="_blank" class="directions-btn">Obtener Direcciones a tu Árbol</a>
        </div>

        <div class="tree-details text-center">
            <h4 class="mb-4">Información del Árbol</h4>
            <table class="table table-bordered tree-info-table mx-auto">
                <tr>
                    <th>Nombre del Estudiante</th>
                    <td><?php echo htmlspecialchars($nombre_estudiante); ?></td>
                </tr>
                <tr>
                    <th>Fecha de Registro</th>
                    <td><?php echo htmlspecialchars($fecha_registro); ?></td>
                </tr>
                <tr>
                    <th>Latitud</th>
                    <td><?php echo htmlspecialchars($lat); ?></td>
                </tr>
                <tr>
                    <th>Longitud</th>
                    <td><?php echo htmlspecialchars($lng); ?></td>
                </tr>
                <tr>
                    <th>Altura (m)</th>
                    <td><?php echo htmlspecialchars($altura); ?> m</td>
                </tr>
                <tr>
                    <th>Circunferencia (m)</th>
                    <td><?php echo htmlspecialchars($circunferencia); ?> m</td>
                </tr>
            </table>
        </div>

        <!-- Tree Image -->
        <div class="text-center mt-4">
            <h4>Foto del Árbol</h4>
            <?php if ($foto_url): ?>
                <img src="<?php echo htmlspecialchars($foto_url); ?>" alt="Foto del Árbol" class="tree-image img-fluid rounded shadow" />
            <?php else: ?>
                <div class="tree-image text-center p-4 border">
                    <p>No se ha subido ninguna imagen aún.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="text-center mt-4">
            <button class="btn-all-trees" onclick="window.location.href='allTrees.php'">Ver Todos los Árboles</button>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer text-center mt-auto">
        <div class="container">
            <img src="../img/logo_Ceutec.png" alt="Logo" style="max-width: 100px;">
            <p>© 2024 Proyecto de Siembra de Árboles</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCkpDesi8hmws4NiAbYzRWzgJnu7lHCX_s"></script>
    <script>
    function initMap() {
        var treeLocation = { lat: parseFloat('<?php echo $lat; ?>'), lng: parseFloat('<?php echo $lng; ?>') };

        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15,
            center: treeLocation
        });

        var marker = new google.maps.Marker({
            position: treeLocation,
            map: map,
            title: 'Tu Árbol'
        });
    }

    window.onload = initMap;
    </script>
</body>
</html>
