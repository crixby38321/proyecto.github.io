<?php
include 'db_config.php';
session_start();

header('Content-Type: application/json'); 

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not authenticated."]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];

    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $altura = $_POST['altura'];
    $circunferencia = $_POST['circunferencia'];
    $imageURL = $_POST['imageURL'];

    $fecha_siembra = date('Y-m-d');

    $stmt = $conn->prepare("INSERT INTO arboles (latitude, longitude, altura, circunferencia, fecha_siembra, estudiante_id, foto) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ddsssis", $latitude, $longitude, $altura, $circunferencia, $fecha_siembra, $user_id, $imageURL);

    if ($stmt->execute()) {

        echo json_encode(["status" => "success", "message" => "Tree registered successfully"]);
    } else {

        echo json_encode(["status" => "error", "message" => "Error: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>
