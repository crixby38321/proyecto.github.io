<?php
include 'db_config.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $numero_cuenta = $_POST['numero_cuenta'];
    $nombre = $_POST['nombre'];
    $contraseña = $_POST['contraseña'];

    $stmt = $conn->prepare("SELECT id, contraseña FROM usuarios WHERE numero_cuenta = ? AND nombre = ?");
    $stmt->bind_param("ss", $numero_cuenta, $nombre);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password);
        $stmt->fetch();

        if (password_verify($contraseña, $hashed_password)) {
            $_SESSION['user_id'] = $user_id;
            $_SESSION['numero_cuenta'] = $numero_cuenta;
            $_SESSION['nombre'] = $nombre;
            
            echo json_encode(["status" => "success"]);
            
        } else {
            echo json_encode(["status" => "error", "message" => "Contraseña incorrecta. Intenta de nuevo."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Número de cuenta o nombre incorrecto. Intenta de nuevo."]);
    }

    $stmt->close();
    $conn->close();
}
