<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

include 'db_config.php';

$stmt = $conn->prepare("SELECT arboles.id, arboles.latitude, arboles.longitude, arboles.altura, arboles.circunferencia, usuarios.nombre 
                        FROM arboles 
                        JOIN usuarios ON arboles.estudiante_id = usuarios.id");
$stmt->execute();
$result = $stmt->get_result();

$trees = [];
while ($row = $result->fetch_assoc()) {
    $trees[] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Todos los Árboles</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        #map { height: 500px; width: 100%; margin-bottom: 30px; }
        .tree-table {
            margin-top: 20px;
        }
        .focus-btn, .info-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }
        .focus-btn:hover, .info-btn:hover {
            background-color: #0056b3;
        }
        .jumbotron {
            background-color: rgba(233, 236, 239, 0.9);
            padding: 1.5rem 1rem;
            margin-bottom: 1.5rem;
        }
        .footer {
            padding: 20px 0;
            background-color: #343a40;
            color: white;
        }
        .navbar-brand img {
            max-height: 50px;
            margin-right: 10px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="../img/logo_Ceutec.png" alt="Logo">
                Siembra de Árboles
            </a>
        </div>
    </nav>

    <div class="jumbotron text-center">
        <div class="container">
            <h1 class="display-5">Ver Todos los Árboles Registrados</h1>
        </div>
    </div>

    <div class="container mt-3">
        <div id="map"></div>

        <table class="table table-bordered tree-table">
            <thead>
                <tr>
                    <th>Nombre del Estudiante</th>
                    <th>Altura (m)</th>
                    <th>Circunferencia (m)</th>
                    <th>Acción</th>
                    <th>Más Información</th> <!-- New Column for More Info -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trees as $index => $tree): ?>
                <tr>
                    <td><?php echo htmlspecialchars($tree['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($tree['altura']); ?> m</td>
                    <td><?php echo htmlspecialchars($tree['circunferencia']); ?> m</td>
                    <td><button class="focus-btn" onclick="focusTree(<?php echo $index; ?>)">Ver en el Mapa</button></td>
                    <td>
                        <!-- More Info button redirects to mapa.php with tree ID -->
                        <a href="mapa.php?tree_id=<?php echo htmlspecialchars($tree['id']); ?>" class="info-btn">Más Información</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <footer class="footer text-center mt-auto">
        <div class="container">
            <img src="../img/logo_Ceutec.png" alt="Logo" style="max-width: 100px;">
            <p>© 2024 Proyecto de Siembra de Árboles</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCkpDesi8hmws4NiAbYzRWzgJnu7lHCX_s"></script>
    <script>
    var map;
    var markers = [];
    var trees = <?php echo json_encode($trees); ?>;

    function initMap() {
        var centerLocation = { lat: parseFloat(trees[0].latitude), lng: parseFloat(trees[0].longitude) };

        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 13,
            center: centerLocation
        });

        trees.forEach(function(tree, index) {
            var latLng = new google.maps.LatLng(parseFloat(tree.latitude), parseFloat(tree.longitude));
            var marker = new google.maps.Marker({
                position: latLng,
                map: map,
                title: 'Árbol de ' + tree.nombre,
                icon: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png'
            });
            markers.push(marker);
        });
    }

    function focusTree(index) {
        markers.forEach(function(marker, i) {
            if (i === index) {
                marker.setIcon('http://maps.google.com/mapfiles/ms/icons/blue-dot.png');
                map.setZoom(15);
                map.setCenter(marker.getPosition());
            } else {
                marker.setIcon('http://maps.google.com/mapfiles/ms/icons/red-dot.png'); 
            }
        });
    }

    window.onload = initMap;
    </script>
</body>
</html>
