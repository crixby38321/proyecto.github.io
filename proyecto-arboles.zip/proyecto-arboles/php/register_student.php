<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $numero_cuenta = $_POST['numero_cuenta'];
    $nombre = $_POST['nombre'];
    $contraseña = $_POST['contraseña'];
    $confirm_contraseña = $_POST['confirm_contraseña'];

    // Check if passwords match
    if ($contraseña !== $confirm_contraseña) {
        echo json_encode(["status" => "error", "message" => "Las contraseñas no coinciden. Intenta de nuevo."]);
        exit;
    }

    // Hash the password
    $hashed_contraseña = password_hash($contraseña, PASSWORD_DEFAULT);

    // Check if the account number already exists
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE numero_cuenta = ?");
    $stmt->bind_param("s", $numero_cuenta);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Account already exists
        echo json_encode(["status" => "error", "message" => "El número de cuenta ya está registrado."]);
    } else {
        // Insert new user into the database
        $stmt = $conn->prepare("INSERT INTO usuarios (numero_cuenta, nombre, contraseña) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $numero_cuenta, $nombre, $hashed_contraseña);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Registro exitoso. Ahora puedes iniciar sesión."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error en el registro. Por favor, intenta de nuevo."]);
        }
    }

    $stmt->close();
    $conn->close();
}
?>
